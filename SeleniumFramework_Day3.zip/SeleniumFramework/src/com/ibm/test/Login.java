package com.ibm.test;


import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import junit.framework.Assert;

public class Login {
	
	@Test 
	 public void login() throws FileNotFoundException, IOException
	 {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		Properties p = new Properties();
		p.load(new FileInputStream("TestData/data.properties"));
		driver.get(p.getProperty("url"));
		driver.findElement(By.name("email")).sendKeys(p.getProperty("user"));
		driver.findElement(By.name("pword")).sendKeys(p.getProperty("password"));
		driver.findElement(By.xpath("/html/body/div/div/div/div[2]/form/button")).click();
		Assert.assertTrue(driver.findElement(By.partialLinkText("Logout")).isDisplayed());
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id=\"page-wrapper\"]/div/div[1]/div/h1")).isDisplayed());
		driver.findElement(By.partialLinkText("Logout")).click();
		driver.quit();
		
	 }
}
